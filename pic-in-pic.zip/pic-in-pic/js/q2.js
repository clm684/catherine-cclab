function q2Choice1(){
    creatureChoiceIndex = 0;
}

function q2Choice2(){
    creatureChoiceIndex = 1;
}